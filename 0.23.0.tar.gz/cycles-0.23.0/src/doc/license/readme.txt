
This program uses code from various sources, the default license is Apache 2.0
for all code, with the following exceptions.

Modified BSD License
* Code adapated from Open Shading Language
* Sobol direction vectors
* Matrix inversion code from OpenEXR
* MD5 Hash code

MIT license
* Approximate Catmull Clark subdivision code

Boost License
* Boost and OpenCL dynamic loading
